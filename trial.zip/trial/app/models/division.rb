class Division < ApplicationRecord
  belongs_to :standard
end
