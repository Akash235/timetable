class Standard < ApplicationRecord

	has_many :divisions
end
