class Subject < ApplicationRecord
  belongs_to :teacher
end
