require 'test_helper'

class StandardTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
